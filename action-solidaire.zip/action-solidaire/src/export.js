/**
 * export.js — Utilitaire d'export CSV pour le Dashboard Action! Solidaire
 * Compatible Office 365 / Excel / SharePoint
 * Auteur : Amine OUALLA
 */

/**
 * Convertit un tableau d'objets JSON en chaîne CSV
 * @param {Array} data - Tableau d'objets à exporter
 * @param {string} separator - Séparateur de colonnes (défaut: ";")
 * @returns {string} Contenu CSV formaté
 */
function toCSV(data, separator = ";") {
  if (!data || data.length === 0) return "";

  const headers = Object.keys(data[0]);
  const headerRow = headers.join(separator);

  const rows = data.map(row =>
    headers.map(h => {
      const val = row[h] ?? "";
      // Encapsuler les valeurs contenant le séparateur ou des guillemets
      const str = String(val).replace(/"/g, '""');
      return str.includes(separator) || str.includes('"') || str.includes("\n")
        ? `"${str}"`
        : str;
    }).join(separator)
  );

  return [headerRow, ...rows].join("\r\n");
}

/**
 * Déclenche le téléchargement d'un fichier CSV dans le navigateur
 * @param {Array} data - Données à exporter
 * @param {string} filename - Nom du fichier sans extension
 */
function downloadCSV(data, filename = "export_action_solidaire") {
  const csv = toCSV(data);
  // BOM UTF-8 pour compatibilité Excel
  const bom = "\uFEFF";
  const blob = new Blob([bom + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);

  const link = document.createElement("a");
  link.href = url;
  link.download = `${filename}_${formatDate(new Date())}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Formate une date en YYYYMMDD pour le nom de fichier
 * @param {Date} date
 * @returns {string}
 */
function formatDate(date) {
  return date.toISOString().slice(0, 10).replace(/-/g, "");
}

/**
 * Filtre les données selon un critère avant export
 * @param {Array} data - Tableau source
 * @param {string} key - Clé sur laquelle filtrer
 * @param {string} value - Valeur à matcher
 * @returns {Array} Données filtrées
 */
function filterBy(data, key, value) {
  if (!key || !value || value === "all") return data;
  return data.filter(item => item[key] === value);
}

/**
 * Export missions filtrées (ex : toutes les missions "réalisées" IDF)
 * Usage depuis le dashboard :
 *   exportMissions({ statut: "réalisée", region: "IDF" })
 */
async function exportMissions(filters = {}) {
  try {
    const response = await fetch("./data/missions.json");
    let data = await response.json();

    Object.entries(filters).forEach(([key, val]) => {
      data = filterBy(data, key, val);
    });

    const label = Object.values(filters).join("_") || "toutes";
    downloadCSV(data, `missions_${label}`);
    console.log(`✅ Export missions réussi — ${data.length} lignes`);
  } catch (err) {
    console.error("❌ Erreur export missions :", err);
  }
}

/**
 * Export du réseau des référents
 */
async function exportReferents(filters = {}) {
  try {
    const response = await fetch("./data/referents.json");
    let data = await response.json();

    Object.entries(filters).forEach(([key, val]) => {
      data = filterBy(data, key, val);
    });

    downloadCSV(data, "referents_action");
    console.log(`✅ Export référents réussi — ${data.length} lignes`);
  } catch (err) {
    console.error("❌ Erreur export référents :", err);
  }
}

/**
 * Export associations partenaires
 */
async function exportAssociations() {
  try {
    const response = await fetch("./data/associations.json");
    const data = await response.json();
    downloadCSV(data, "associations_partenaires");
    console.log(`✅ Export associations réussi — ${data.length} lignes`);
  } catch (err) {
    console.error("❌ Erreur export associations :", err);
  }
}

// Exposition globale pour utilisation depuis le dashboard
if (typeof window !== "undefined") {
  window.ActionExport = { exportMissions, exportReferents, exportAssociations, downloadCSV, toCSV };
}

// Export Node.js (tests)
if (typeof module !== "undefined") {
  module.exports = { toCSV, downloadCSV, filterBy, formatDate };
}
