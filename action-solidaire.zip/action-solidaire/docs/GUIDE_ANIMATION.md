# 📖 Guide d'animation du réseau associatif — Programme Action!

> Document à usage interne — Chef de projet Engagement Solidaire · Périmètre IDF / Nord

---

## 1. Objectif du guide

Ce guide accompagne le Chef de projet dans l'animation de son réseau de partenaires associatifs. Il couvre les étapes clés : identification, qualification, intégration sur la plateforme, suivi et valorisation.

---

## 2. Identifier de nouveaux partenaires associatifs

### Critères de sélection

| Critère | Description |
|---|---|
| Statut juridique | Association loi 1901 reconnue d'intérêt général |
| Capacité d'accueil | Minimum 4 collaborateurs par mission |
| Durée de mission | Entre 2h et 8h (demi-journée ou journée) |
| Localisation | IDF ou région Nord (accessibilité depuis les sites TotalEnergies) |
| Thématique | Alignée avec les axes ESS prioritaires (voir section 5) |

### Sources de prospection

- **Annuaires** : France Bénévolat, Associations.gouv.fr, Le Mouvement Associatif
- **Réseaux locaux** : CDVA, UDES, CRESS Île-de-France, CRESS Hauts-de-France
- **Recommandations** : réseau interne des référents, collaborateurs bénévoles
- **Événements** : Forums associatifs, salons ESS (Salon des Solidarités, etc.)

---

## 3. Qualifier une association

### Grille de qualification (à compléter en premier contact)

```
□ Nom de l'association :
□ Interlocuteur bénévoles :
□ Téléphone / Email :
□ Thématique principale :
□ Types de missions possibles :
□ Nombre de bénévoles pouvant accueillir simultanément :
□ Disponibilités (jours, périodes) :
□ Localisation exacte (adresse, accessibilité transports) :
□ Besoins spécifiques (compétences, matériel) :
□ Expérience avec des bénévoles d'entreprise : Oui / Non
```

---

## 4. Intégrer un partenaire sur la plateforme

### Étapes administrateur

1. **Créer le profil association** — Nom, logo, description (200 mots max), contact référent, thématique
2. **Définir les missions** avec l'association :
   - Titre court et engageant (60 caractères max)
   - Description détaillée : contexte, déroulé, impact attendu
   - Nombre de places, date, durée, lieu, niveau de difficulté physique
3. **Paramétrer les droits** — L'association reçoit un accès pour modifier ses missions et valider les inscriptions
4. **Test de validation** — Vérifier l'affichage public avec un compte de test collaborateur
5. **Notification interne** — Informer le référent de secteur + push mail aux collaborateurs concernés

---

## 5. Axes thématiques ESS prioritaires

| # | Thématique | Exemples de missions |
|---|---|---|
| 1 | Alimentation solidaire | Collectes, distributions, maraudes |
| 2 | Insertion professionnelle | Mentorat CV, simulations entretien |
| 3 | Inclusion numérique | Ateliers seniors, formation débutants |
| 4 | Environnement | Chantiers nature, nettoyage, sensibilisation |
| 5 | Éducation & jeunesse | Tutorat scolaire, parrainage étudiant |
| 6 | Grand âge & isolement | Visites, bricolage, compagnie |
| 7 | Logement social | Accompagnement administratif, travaux légers |
| 8 | ESS & innovation | Hackathons, coaching entrepreneurs sociaux |

---

## 6. Suivre et fidéliser les partenaires

### Rythme de contact recommandé

| Fréquence | Action |
|---|---|
| Mensuelle | Email de suivi : taux de remplissage des missions, retours collaborateurs |
| Trimestrielle | Appel ou visio de bilan avec l'interlocuteur référent |
| Semestrielle | Bilan quantitatif + qualitatif, renouvellement des missions |
| Annuelle | Compte-rendu d'impact (heures réalisées, nb collaborateurs, verbatims) |

### Indicateurs de suivi

- Taux de remplissage des missions (objectif : > 80%)
- Note de satisfaction association (sur 5)
- Nombre de missions renouvelées
- Délai moyen de réponse association aux inscriptions

---

## 7. Valoriser les partenariats

- **Post-mission** : demander un verbatim association + photo pour Yammer
- **Rapport d'impact annuel** : inclure données chiffrées par association
- **Événements** : inviter les associations au Forum annuel La Défense
- **Mise en avant** : article e-café, post Yammer, newsletter interne

---

*Dernière mise à jour : octobre 2025 — Chef de projet Engagement Solidaire, périmètre IDF/Nord*
