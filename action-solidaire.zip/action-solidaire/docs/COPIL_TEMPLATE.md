# 📋 Modèle COPIL mensuel — Programme Action! · IDF / Nord

---

**COPIL Action! — [Mois Année]**
**Date** : [JJ/MM/AAAA] · **Heure** : [HH:MM] → [HH:MM]
**Format** : Visio Teams / Présentiel [Site]
**Animateur** : Amine OUALLA, Chef de projet IDF/Nord
**Participants** : [Liste des référents présents]
**Excusés** : [Liste]
**Rédacteur** : [Prénom NOM]

---

## 1. Points KPIs du mois — [Mois]

| Indicateur | Réalisé | Objectif mensuel | Écart | Tendance |
|---|---|---|---|---|
| Heures d'engagement | [X] | [X] | [±X%] | ↗ / → / ↘ |
| Participants uniques | [X] | [X] | [±X%] | ↗ / → / ↘ |
| Missions réalisées | [X] | [X] | [±X%] | ↗ / → / ↘ |
| Taux de remplissage missions | [X%] | 80% | [±X pts] | ↗ / → / ↘ |
| Nouvelles associations | [X] | — | — | — |
| Satisfaction associations (moy.) | [X/5] | ≥ 4.5/5 | — | ↗ / → / ↘ |

**Cumul YTD (janvier → [Mois])** :
- Heures totales : [X] / [X objectif annuel] = **[X%]**
- Participants uniques : [X] collaborateurs engagés
- Missions réalisées : [X]

---

## 2. Faits marquants du mois

### ✅ Points positifs
- [ ] [Événement ou résultat notable à valoriser]
- [ ] [Nouvelle association intégrée / partenariat signé]
- [ ] [Initiative d'un référent à mettre en avant]

### ⚠️ Points d'attention
- [ ] [Difficulté rencontrée + plan d'action associé]
- [ ] [Mission sous-remplie → raison identifiée ?]
- [ ] [Référent inactif → action de relance prévue ?]

---

## 3. Retours terrain des référents

> *(Tour de table — 2 min par référent)*

| Référent | Entité | Point clé partagé | Action identifiée |
|---|---|---|---|
| [Prénom N.] | [BU] | | |
| [Prénom N.] | [BU] | | |
| [Prénom N.] | [BU] | | |

---

## 4. Agenda opérationnel — [Mois suivant]

| Date | Événement | Référent pilote | Statut |
|---|---|---|---|
| [JJ/MM] | [Mission / Événement] | [Prénom N.] | À confirmer / Confirmé |
| [JJ/MM] | [Mission / Événement] | [Prénom N.] | À confirmer / Confirmé |
| [JJ/MM] | e-café mensuel Action! | Amine O. | Confirmé |
| [JJ/MM] | Push mail mensuel | Amine O. | Planifié |

---

## 5. Chantiers en cours

| Chantier | Responsable | Avancement | Prochaine étape |
|---|---|---|---|
| Intégration [Association X] sur la plateforme | Amine O. | 60% | Validation fiche mission |
| Refonte page SharePoint ressources | [Référent] | 30% | Livraison [date] |
| Recrutement référent [entité vacante] | Amine O. | Prospection en cours | Présentation candidats [date] |

---

## 6. Décisions prises

| # | Décision | Décideur | Échéance |
|---|---|---|---|
| 1 | | | |
| 2 | | | |

---

## 7. Actions à suivre

| # | Action | Responsable | Échéance | Statut |
|---|---|---|---|---|
| 1 | | | [JJ/MM] | 🔴 À faire |
| 2 | | | [JJ/MM] | 🟡 En cours |
| 3 | | | [JJ/MM] | 🟢 Réalisé |

---

## 8. Prochain COPIL

**Date** : [JJ/MM/AAAA] · **Heure** : [HH:MM]
**Format** : [Visio Teams / Présentiel]
**Ordre du jour prévisionnel** : [Points à aborder]

---

*Document rédigé par Amine OUALLA — Chef de projet Action!, IDF / Nord*
*Diffusé sur SharePoint > Action! > COPILs > [Mois Année]*
