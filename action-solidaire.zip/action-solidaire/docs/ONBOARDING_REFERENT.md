# 🎯 Kit d'intégration — Nouveau référent Action!

> Bienvenue dans le réseau des référents du programme Action! · Périmètre IDF / Nord

---

## Votre rôle en quelques mots

En tant que **référent Action!** dans votre entité, vous êtes l'ambassadeur du programme d'engagement solidaire auprès de vos collègues. Vous n'avez pas besoin d'être expert en associatif — votre rôle est avant tout de **faire le lien** entre le programme et votre équipe.

**Temps estimé** : 2 à 4h par mois selon l'activité de votre entité.

---

## Vos 5 missions clés

| # | Mission | Fréquence |
|---|---|---|
| 1 | Promouvoir les missions disponibles auprès de vos collègues | Mensuelle |
| 2 | Accompagner les collaborateurs dans leur inscription | À la demande |
| 3 | Relayer les communications du programme (Yammer, Teams, push mail) | Mensuelle |
| 4 | Participer aux COPIL et webinaires réseau | Trimestrielle |
| 5 | Remonter les besoins et retours de terrain au chef de projet | Continue |

---

## Vos accès et outils

### Plateforme d'engagement
- **URL** : [plateforme.action-solidaire.totalenergies.com](#)
- **Accès** : compte référent — droits élargis (consultation de toutes les missions IDF/Nord, suivi des inscrits de votre entité)
- **À faire en premier** : compléter votre profil référent (photo, BU, contact)

### SharePoint du programme
- **URL** : [sharepoint.totalenergies.com/action-solidaire](#)
- **Contenu** : ressources de communication, guides, présentations COPIL, kits d'animation
- **À faire** : rejoindre le site et vous abonner aux alertes

### Communauté Teams
- **Nom** : Action! — Réseau des référents
- **Canal dédié** : #idf-nord
- **À faire** : activer les notifications du canal

### Communauté Yammer
- **Groupe** : Action! Solidaire TotalEnergies
- **À faire** : rejoindre le groupe et liker la page

---

## Calendrier type d'un référent (année N)

| Période | Événement |
|---|---|
| Janvier | COPIL de lancement — objectifs et calendrier annuel |
| Mars | Webinaire référents — bilan T1 & nouvelles missions |
| Avril–Mai | Forum Associations (La Défense) — mobilisation collaborateurs |
| Juin | COPIL mi-année — bilan 6 mois |
| Septembre | Webinaire référents — rentrée solidaire |
| Novembre | Grande Collecte Alimentaire — mobilisation nationale |
| Décembre | Noël solidaire — collecte jouets, maraudes hivernales |
| Décembre | COPIL bilan annuel — chiffres clés & perspectives |

---

## Vos contacts directs

| Rôle | Contact |
|---|---|
| Chef de projet IDF/Nord | Amine OUALLA — amineoualla69@gmail.com |
| Plateforme (support technique) | support@plateforme-action.fr |
| Urgence logistique événement | +33 7 51 17 89 61 |

---

## FAQ référents

**Q : Un collègue veut participer mais ne trouve pas la mission sur la plateforme ?**
→ Vérifier que son compte est bien activé. Si oui, me transmettre son email, je crée la mission manuellement.

**Q : Une association annule une mission à J-3 ?**
→ Me prévenir immédiatement par Teams ou téléphone. Je gère la communication auprès des inscrits et cherche une alternative.

**Q : Mon manager bloque la participation d'un collaborateur ?**
→ Partager le mémo RH (disponible sur SharePoint) rappelant les 3 jours d'engagement inscrits dans la politique RSE de TotalEnergies.

**Q : Je veux proposer une nouvelle association partenaire ?**
→ Remplir la fiche de qualification (SharePoint > Ressources > Nouvelles associations) et me l'envoyer. Je prends le relais.

---

*Programme Action! · TotalEnergies · Chef de projet IDF/Nord : Amine OUALLA*
