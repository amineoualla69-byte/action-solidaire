# 📣 Plan de communication annuel — Programme Action! · IDF / Nord

> Chef de projet : Amine OUALLA · Périmètre IDF + Nord France · Année 2025–2026

---

## Objectifs de communication

| Objectif | Indicateur | Cible |
|---|---|---|
| Notoriété programme | % collaborateurs connaissant Action! | > 70% |
| Engagement actif | Taux de participation | > 8% (vs 6% actuel) |
| Rétention | Taux de re-participation | > 40% |
| Satisfaction | Note collaborateurs post-mission | ≥ 4.5/5 |

---

## Canaux disponibles et rôles

| Canal | Fréquence | Cible | Objectif |
|---|---|---|---|
| **Push mail** (Outlook) | Mensuel | Tous collaborateurs IDF/Nord | Information missions disponibles |
| **Communauté Yammer** | Hebdo | Collaborateurs engagés | Animation, témoignages, live updates |
| **e-café mensuel** (Teams) | Mensuel | Volontaires + référents | Présentation missions, Q&A |
| **Newsletter référents** | Bimensuel | Réseau des 30 référents | Pilotage, ressources, nouveautés |
| **SharePoint** | En continu | Référents + RH | Ressources, documents, KPIs |
| **Intranet TotalEnergies** | Trimestriel | Tous collaborateurs | Articles impact, valorisation |
| **Affichage sites** | Événementiel | Collaborateurs sur site | Collectes, forums, missions urgentes |

---

## Calendrier éditorial annuel

### Janvier — Lancement de l'année solidaire

| Date | Action | Canal | Responsable |
|---|---|---|---|
| 6 jan | Email de lancement — bonne année solidaire | Push mail | Amine O. |
| 10 jan | Post Yammer : objectifs 2025 + appel à participation | Yammer | Amine O. |
| 15 jan | e-café #1 : présentation programme & nouvelles missions | Teams | Amine O. |
| 20 jan | COPIL référents — objectifs annuels | Teams | Amine O. |

### Février — Solidarité hivernale

| Date | Action | Canal | Responsable |
|---|---|---|---|
| 3 fév | Push mail : missions hivernales disponibles | Push mail | Amine O. |
| 12 fév | Post Yammer : témoignage collaborateur maraude | Yammer | Référent |
| 19 fév | e-café #2 : focus thématique alimentation solidaire | Teams | Amine O. |

### Mars — Mois de la RSE

| Date | Action | Canal | Responsable |
|---|---|---|---|
| 1 mar | Article intranet : bilan T1 Action! | Intranet | Amine O. |
| 8 mar | Push mail : missions Semaine de la femme | Push mail | Amine O. |
| 15 mar | Webinaire référents — bilan T1 & best practices | Teams | Amine O. |
| 22 mar | Post Yammer : Semaine de la Terre — missions env. | Yammer | Amine O. |

### Avril — Forum Associations La Défense

| Date | Action | Canal | Responsable |
|---|---|---|---|
| 1 avr | Teaser Forum Associations | Yammer + Affichage | Amine O. |
| 3 avr | **Forum Associations — Coupole La Défense** | Présentiel | Amine O. |
| 7 avr | Post-événement : photos, chiffres, témoignages | Yammer + Intranet | Amine O. |
| 15 avr | e-café #4 : retour Forum + missions printemps | Teams | Amine O. |

### Mai — Printemps solidaire

| Date | Action | Canal | Responsable |
|---|---|---|---|
| 5 mai | Push mail : collecte alimentaire printemps | Push mail | Amine O. |
| 10 mai | **Grande Collecte Alimentaire** | Présentiel | Référents |
| 20 mai | Valorisation collecte : kg collectés, nb participants | Yammer | Amine O. |

### Juin — Mi-année, bilan & momentum

| Date | Action | Canal | Responsable |
|---|---|---|---|
| 2 jun | COPIL référents mi-année | Teams | Amine O. |
| 10 jun | Article intranet : bilan S1 — chiffres clés impact | Intranet | Amine O. |
| 20 jun | **Hackathon solidaire** | Présentiel | Amine O. |
| 25 jun | e-café #6 : bilan semestre + preview été | Teams | Amine O. |

### Juillet–Août — Période creuse (maintien du lien)

| Date | Action | Canal | Responsable |
|---|---|---|---|
| 1 jul | Push mail allégé : missions estivales | Push mail | Amine O. |
| 15 aoû | Post Yammer : mission en image (photos été) | Yammer | Référent |

### Septembre — Rentrée solidaire

| Date | Action | Canal | Responsable |
|---|---|---|---|
| 1 sep | Push mail rentrée : nouvelles missions + rappel 24h | Push mail | Amine O. |
| 5 sep | Webinaire référents — rentrée, agenda Q4 | Teams | Amine O. |
| 15 sep | e-café #9 : missions d'automne | Teams | Amine O. |
| 20 sep | **Accueil bénéficiaires site Michelet** | Présentiel | Amine O. |

### Octobre — Mois associatif

| Date | Action | Canal | Responsable |
|---|---|---|---|
| 1 oct | Article intranet : 3 portraits de bénévoles | Intranet | Amine O. |
| 10 oct | Push mail : missions spéciales mois associatif | Push mail | Amine O. |
| 20 oct | e-café #10 : témoignage association partenaire invitée | Teams | Amine O. |

### Novembre — Grande Collecte & hiver solidaire

| Date | Action | Canal | Responsable |
|---|---|---|---|
| 10 nov | **Grande Collecte Alimentaire nationale** | Présentiel | Référents |
| 12 nov | Valorisation collecte immédiate | Yammer | Amine O. |
| 20 nov | Push mail : maraudes hivernales — inscriptions ouvertes | Push mail | Amine O. |
| 28 nov | e-café #11 : spécial hiver solidaire | Teams | Amine O. |

### Décembre — Noël solidaire & bilan annuel

| Date | Action | Canal | Responsable |
|---|---|---|---|
| 5 déc | Push mail : collecte jouets + maraudes Noël | Push mail | Amine O. |
| 10 déc | **Mission Noël solidaire** | Présentiel | Référents |
| 15 déc | COPIL bilan annuel référents | Teams | Amine O. |
| 18 déc | Article intranet : bilan annuel Action! — impact 2025 | Intranet | Amine O. |
| 22 déc | Post Yammer : merci & bonne année solidaire | Yammer | Amine O. |

---

## Gabarit push mail mensuel

```
Objet : [Action! Solidaire] Les missions de [Mois] sont ouvertes 🤝

Bonjour [Prénom],

[ACCROCHE — 1 phrase impact ou chiffre du mois précédent]

🗓️ LES MISSIONS DU MOIS
→ [Mission 1] — [Date] — [Nb places] places — [Association]
→ [Mission 2] — [Date] — [Nb places] places — [Association]
→ [Mission 3] — [Date] — [Nb places] places — [Association]

[Bouton] Je m'inscris sur la plateforme

💬 ILS L'ONT FAIT
"[Verbatim collaborateur]" — [Prénom], [BU]

📅 À VOS AGENDAS
→ e-café Action! : [Date] [Heure] [Lien Teams]
→ Prochain forum associations : [Date]

Des questions ? Contactez votre référent [Nom] ou écrivez-moi directement.

Amine OUALLA · Chef de projet Action! IDF/Nord
amineoualla69@gmail.com
```

---

*Document de travail interne — mise à jour mensuelle*
*Chef de projet Action! · Amine OUALLA · Périmètre IDF / Nord*
